Galactic Venture by Mickey Kudlo

Feel free to edit the .ini files and tweak or add stuff as you want.
If you add some decent things then please send it to me and I might add it.

Email any comments to mickey@rpgwo.com with the subject being "Galactic Venture"

Thanks



03/27/05

- using galacticventure.exe for the exe name now. Delete gv.exe and/or strategy.exe files.
- tried to make the A* pathfinding work aesthetically better but it was stubburn, so the paths
  it finds are still the shortest but are weird looking at times (not straight, etc)
- smooth motion of units! Just need animations drawn... anyone? anyone?
- re-did the operation of buildings... operate.ini file used
- large size buildings... only 2x2 supported right now, still needs work
- solar power generator and infrared radar station (non-portable, stronger, better)
- ally view, controls how your employees react to other non-employees(monsters)
- in map.ini, you can specify other "companies" like the wolves, deer, etc
- made a setup program to install it


03/16/05

- employee view list- click on image to select/center on them, no scroll support yet
- cooking - on the deer/wolf carcasses using butcher knife and food processor
- Grayvyn Marauders!!!
- made the wolf/deer more simulated, food needs, hunting/grazing, eating, etc
- using A* pathfinding algorithm, works awesome! Never get stuck again! yeah right
- fixed a lot of bugs with regeneration of dead employees
- mining building, have an employee enter it then right click on the employee and select operate...
  It can go deeper than the portable ore extractor


03/04/05 

- use geological scanner to prospect for ore, the M button on the right on the mini
  map will toggle the ore markers
- use ore extrator to get the ore from a spot
- spot must be clear to use scanner or extractor
- use refiner on raw ore to get ore bars
- when you mine it slowly reduces the ore there, until you have to go deeper and deeper
  and it becomes harder to extract
- growth and reproduction for plants
- map.ini and map type selection, go ahead and add your own! still adding more to it
- fixed electric sound
- tutorial should stop now after last completed one
- B button on right of mini-map toggles buildings on/off
- lower right M mini map mode button toggles normal and mining
- added food requirements on employees, they will auto eat when hungry, loose HP if starving
- added red apple trees and ability to pick apples although it seems buggy and needs tracking down


02/15/05

- neat little interactive tutorial, work in progress
- added a laser hit animation, sparks
- some items use electrical power to operate, power level is in blue, use power cell on them to refuel
- use power cells on solar power generator to recharge
- portable solar power generator gets energy from local sun
- icon
- regeneration of killed employees into mothership, costs 100 credits
- if picking up overburdens then it reduces the qty to an amount they can pickup
- if giving overburdens then it reduces the qty to an amount they can give
- message transparent option in Options
- date, one virtual day is 1 real minute
- salary costs, every 30 v-days it auto-pays your employees, if you don't have the credits then they might quit
- in setup.ini you can adjust the SalaryFactor in case it is too high
- company view, shows employees and salaries, can pay employees you owe credits here so they won't quit
- new version of saved games, sorry, doubt old files will load
 


02/07/05

- added more sounds: different lasers, wolf sound, radar ping sound, door, etc
- added a setup.ini with some interesting adjustable settings
- optimized my event system to be faster/better/stronger!
- employees if working will attack enemies in range, then when done go back to working
- added herbivores- deer but the dam wolves kill them! cool
- admin-showall will show all the map and stuffs
- can train skills during the game now, "T" button
- spare parts needed to repair sentry and radar
- mark II sentry - better
- weapon damage types and intrinsic armor types
- monsters won't attack stuff they can't damage
- wood walls, auto-connect to look pretty, can also tear them down
- wood gates, employees will auto-open them as needed too
- seperate button to show player or building hitpoints in mini-map
- changed format of usage.ini concernig Success= and SuccessQty=
- units should attack the closest target in auto mode
- added the API Sleep() function in the game loop, it got rid of 100% untilization and good FPS still
- sometimes you could see wolves/deer running around outside visible range, I think i got it fixed


01/31/05

- this game is looking very cool so far :)
- official name: Galactic Venture 
- website: www.galacticventure.com
- fixed a few bugs with loading
- mothership, dropship, and market, right click on dropship bin and select Pickup
- fixed all the "array is locked" bugs, I hope
- fixed the not exiting issue
- aerial scout - looks cool
- can spend xp to raise hitpoints


01/26/05

- can save and load games now
- portable radar station
- laser sentries now have no sight range
- players gain spendable XP that can be used to raise skills directly
- can setup custom teams or select the quick team
- can save and load team creation sets
- main menu at startup


01/18/05

- healing players with medic skill
- sounds: combat and usages, building
- repairing buildings
- rifles for infantry
- double click a unit to turn on/off status
- hitpoints bar in tactical map
- players can enter buildings
- players in certain buildings get healed slowly
- double click on a unit inside a unit to get status
- use the /\ button to goto the "carried by" unit
- players in buildings can attack from the buildings if allowed
- fixed building place with resources
- can move resources out of a "site" and back in
- fixed some stacking issues


01/13/05

- been real buggy lately so been squashing them
- combat range and melee
- portable laser sentry
- wolfs roam around so look out!
- looking into more smoother movement
- laser animations


01/10/05 
- beginning of weapons and combat
- arrow keys scroll screen
- build window
- resource window
- usage with stuff in inventory
- building


01/06/05

- can move objects from unit to map - drag and drop like rpgwo
- can move objects from unit to unit - drag and drop like rpgwo
- can move objects from map to unit - right click on object
- status S button and full status screen data
- ESC key pause/unpause
- keypad scrolls view


12/31/04

- unit status screen


12/28/2004

- usage, select unit, right click object, select action
 - only laser saw on pine tree supported at this time
- burden and carrying
- when unit is full burden, they will unload resource at nearest storage place
- units have skills


12/15/2004

- larger/dynamic map size support
- multi-units on one space
- being on higher elevation increases sight range upto 150%
- basic structure/buildings
- tall/wide images
- shadow units (out of visible range but last seen there)
- multi-unit selection: drag box or hold down ctrl while selecting


12/11/2004

- An isometric engine developed for future game(s)
- feel free to edit the unit.ini



Copyright 2005 by Michael "Mickey" Kudlo